"""
Конфигурация приложения.

Все секреты хранятся как SecretStr — маскируются в логах, repr(), traceback.
Значения загружаются из переменных окружения или .env файла.
"""

from __future__ import annotations

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Настройки MCP-сервера для Ozon Seller API."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # --- Ozon API ---
    ozon_client_id: str = Field(
        ..., description="Ozon Seller Client-Id (из личного кабинета)"
    )
    ozon_api_key: SecretStr = Field(
        ..., description="Ozon Seller API Key (срок жизни 180 дней)"
    )
    ozon_api_base_url: str = Field(
        default="https://api-seller.ozon.ru",
        description="Базовый URL Ozon Seller API (не менять!)",
    )

    # --- MCP Auth ---
    mcp_auth_token: SecretStr = Field(
        default=SecretStr(""),
        description="Bearer-токен для аутентификации MCP-клиентов (пусто = без аутентификации)",
    )

    # --- Redis ---
    redis_url: str = Field(
        default="redis://localhost:6379/0",
        description="URL подключения к Redis",
    )
    cache_ttl_seconds: int = Field(
        default=300, ge=0, le=86400,
        description="TTL кэша по умолчанию (секунды)",
    )

    # --- PostgreSQL ---
    postgres_dsn: SecretStr = Field(
        default=SecretStr("postgresql://ozon:secret@localhost:5432/ozon_mcp"),
        description="DSN подключения к PostgreSQL",
    )

    # --- Rate Limiting ---
    rate_limit_rpm: int = Field(
        default=100, ge=1, le=1000,
        description="Макс. запросов к Ozon API в минуту (глобально)",
    )
    rate_limit_write_rpm: int = Field(
        default=10, ge=1, le=100,
        description="Макс. write-запросов к Ozon API в минуту",
    )

    # --- Server ---
    server_name: str = Field(
        default="Ozon Seller MCP Server",
        description="Имя MCP-сервера",
    )
    log_level: str = Field(
        default="INFO",
        description="Уровень логирования (DEBUG, INFO, WARNING, ERROR)",
    )
    transport: str = Field(
        default="stdio",
        description="MCP-транспорт: stdio | streamable-http | sse",
    )
    port: int = Field(
        default=8000, ge=1024, le=65535,
        description="Порт для HTTP-транспорта",
    )

    @field_validator("ozon_api_base_url")
    @classmethod
    def validate_base_url(cls, v: str) -> str:
        """Запрет на изменение базового URL — защита от SSRF."""
        allowed = "https://api-seller.ozon.ru"
        if v != allowed:
            msg = f"ozon_api_base_url должен быть {allowed!r} (защита от SSRF)"
            raise ValueError(msg)
        return v

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        upper = v.upper()
        if upper not in allowed:
            msg = f"log_level должен быть одним из {allowed}"
            raise ValueError(msg)
        return upper


def get_settings() -> Settings:
    """Фабрика настроек (для тестов — можно переопределить)."""
    return Settings()  # type: ignore[call-arg]
