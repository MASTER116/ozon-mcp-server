"""
MCP-инструменты для работы с заказами и аналитикой Ozon.

Read-only: get_fbs_orders, get_fbo_orders, get_analytics, get_finance_report
"""

from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Any

from mcp.server.fastmcp import Context

from ozon_mcp_server.models.orders import (
    GetAnalyticsParams,
    GetFinanceParams,
    GetOrderListParams,
)
from ozon_mcp_server.server import get_app_context, mcp


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_fbs_orders(
    status: str = "awaiting_packaging",
    days_back: int = 7,
    limit: int = 50,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить список FBS-заказов (отправка продавцом) за указанный период.

    FBS = Fulfillment by Seller — продавец сам упаковывает и отправляет.
    Возвращает: номер заказа, товары, статус, адрес доставки.

    Args:
        status: Статус заказов (awaiting_packaging, delivering, delivered, cancelled)
        days_back: За сколько дней назад искать (1-90)
        limit: Макс. количество заказов (1-1000)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    params = GetOrderListParams(
        status=status, days_back=days_back, limit=limit,  # type: ignore[arg-type]
    )

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    now = datetime.now(timezone.utc)
    since = (now - timedelta(days=params.days_back)).strftime("%Y-%m-%dT00:00:00Z")
    to = now.strftime("%Y-%m-%dT23:59:59Z")

    payload = {
        "filter": {
            "status": params.status,
            "since": since,
            "to": to,
        },
        "limit": params.limit,
        "offset": params.offset,
        "with": {
            "analytics_data": True,
            "financial_data": True,
        },
    }

    # Кэш заказов — короткий TTL (2 минуты)
    cache_params = {"status": params.status, "days": params.days_back, "limit": params.limit}
    cached = await app.cache.get("fbs_orders", cache_params)
    if cached:
        await app.audit.log("get_fbs_orders", cache_params, "success", 0)
        return cached

    result = await app.ozon.request("/v3/posting/fbs/list", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.cache.set("fbs_orders", cache_params, result, ttl=120)
    await app.audit.log("get_fbs_orders", cache_params, "success", elapsed)

    return result


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_fbo_orders(
    status: str = "awaiting_packaging",
    days_back: int = 7,
    limit: int = 50,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить список FBO-заказов (отправка со склада Ozon) за период.

    FBO = Fulfillment by Ozon — товар хранится на складе Ozon.
    Аналогично FBA на Amazon.

    Args:
        status: Статус заказов
        days_back: За сколько дней назад (1-90)
        limit: Макс. количество (1-1000)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    params = GetOrderListParams(
        status=status, days_back=days_back, limit=limit,  # type: ignore[arg-type]
    )

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    now = datetime.now(timezone.utc)
    since = (now - timedelta(days=params.days_back)).strftime("%Y-%m-%dT00:00:00Z")
    to = now.strftime("%Y-%m-%dT23:59:59Z")

    payload = {
        "filter": {
            "status": params.status,
            "since": since,
            "to": to,
        },
        "limit": params.limit,
        "offset": params.offset,
    }

    result = await app.ozon.request("/v2/posting/fbo/list", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.audit.log("get_fbo_orders", {"status": params.status}, "success", elapsed)
    return result


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_analytics(
    date_from: str = "",
    date_to: str = "",
    metrics: list[str] | None = None,
    dimensions: list[str] | None = None,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить аналитику продаж из Ozon.

    Метрики: revenue (выручка), ordered_units (заказы), hits_view (просмотры),
    conv_tocart (конверсия в корзину), returns (возвраты).

    Args:
        date_from: Начало периода (YYYY-MM-DD, обязательно)
        date_to: Конец периода (YYYY-MM-DD, обязательно)
        metrics: Метрики (revenue, ordered_units, hits_view и др.)
        dimensions: Измерения (day, week, month, sku, category1...)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    if not date_from or not date_to:
        return {"error": "Укажите date_from и date_to в формате YYYY-MM-DD"}

    params = GetAnalyticsParams(
        date_from=date_from,
        date_to=date_to,
        metrics=metrics or ["revenue", "ordered_units", "hits_view"],  # type: ignore[arg-type]
        dimensions=dimensions or ["day"],  # type: ignore[arg-type]
    )

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    # Аналитика кэшируется дольше (30 минут)
    cache_params = params.model_dump()
    cached = await app.cache.get("analytics", cache_params)
    if cached:
        await app.audit.log("get_analytics", cache_params, "success", 0)
        return cached

    payload = {
        "date_from": params.date_from,
        "date_to": params.date_to,
        "metrics": list(params.metrics),
        "dimension": list(params.dimensions),
        "limit": params.limit,
        "offset": params.offset,
    }

    result = await app.ozon.request("/v1/analytics/data", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.cache.set("analytics", cache_params, result, ttl=1800)
    await app.audit.log("get_analytics", cache_params, "success", elapsed)

    return result


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_finance_report(
    date_from: str = "",
    date_to: str = "",
    page: int = 1,
    page_size: int = 50,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить финансовые транзакции из Ozon.

    Возвращает: начисления, списания, комиссии, штрафы за период.

    Args:
        date_from: Начало периода (YYYY-MM-DD)
        date_to: Конец периода (YYYY-MM-DD)
        page: Номер страницы
        page_size: Размер страницы (1-1000)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    if not date_from or not date_to:
        return {"error": "Укажите date_from и date_to в формате YYYY-MM-DD"}

    params = GetFinanceParams(
        date_from=date_from,
        date_to=date_to,
        page=page,
        page_size=page_size,
    )

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    payload = {
        "filter": {
            "date": {
                "from": f"{params.date_from}T00:00:00.000Z",
                "to": f"{params.date_to}T23:59:59.999Z",
            },
            "transaction_type": params.transaction_type,
        },
        "page": params.page,
        "page_size": params.page_size,
    }

    result = await app.ozon.request("/v3/finance/transaction/list", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.audit.log("get_finance_report", {"from": date_from, "to": date_to}, "success", elapsed)
    return result


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_warehouse_list(ctx: Context | None = None) -> dict[str, Any]:
    """Получить список всех складов продавца (FBS + FBO).

    Возвращает: ID склада, название, тип, статус.
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    # Кэш складов — длинный TTL (1 час)
    cached = await app.cache.get("warehouses", {})
    if cached:
        return cached

    result = await app.ozon.request("/v1/warehouse/list")
    elapsed = (time.monotonic() - start) * 1000

    await app.cache.set("warehouses", {}, result, ttl=3600)
    await app.audit.log("get_warehouse_list", {}, "success", elapsed)

    return result
