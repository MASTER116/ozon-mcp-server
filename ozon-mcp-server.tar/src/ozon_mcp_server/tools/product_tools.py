"""
MCP-инструменты для работы с товарами Ozon Seller API.

Read-only: get_product_list, get_product_info
Write (destructive): update_prices, update_stocks, archive_product
"""

from __future__ import annotations

import time
from typing import Any

from mcp.server.fastmcp import Context

from ozon_mcp_server.models.products import (
    GetProductInfoParams,
    GetProductListParams,
    UpdatePricesParams,
    UpdateStocksParams,
)
from ozon_mcp_server.server import get_app_context, mcp


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_product_list(
    limit: int = 100,
    last_id: str = "",
    visibility: str = "ALL",
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить список товаров магазина на Ozon.

    Возвращает ID товаров и offer_id с пагинацией.
    Фильтрация по видимости: ALL, VISIBLE, INVISIBLE, ARCHIVED и др.

    Args:
        limit: Количество товаров (1-1000, по умолчанию 100)
        last_id: ID для пагинации (из предыдущего ответа)
        visibility: Фильтр видимости (ALL, VISIBLE, INVISIBLE, ARCHIVED...)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    # Валидация через Pydantic
    params = GetProductListParams(
        limit=limit, last_id=last_id, visibility=visibility,  # type: ignore[arg-type]
    )

    # Rate limit
    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    # Кэш
    cache_params = params.model_dump()
    cached = await app.cache.get("products_list", cache_params)
    if cached:
        await app.audit.log("get_product_list", cache_params, "success", 0)
        return cached

    # Запрос к Ozon API
    payload: dict[str, Any] = {
        "filter": {"visibility": params.visibility},
        "limit": params.limit,
    }
    if params.last_id:
        payload["last_id"] = params.last_id
    if params.offer_ids:
        payload["filter"]["offer_id"] = params.offer_ids
    if params.product_ids:
        payload["filter"]["product_id"] = params.product_ids

    result = await app.ozon.request("/v2/product/list", payload)
    elapsed = (time.monotonic() - start) * 1000

    # Кэшируем (5 минут)
    await app.cache.set("products_list", cache_params, result, ttl=300)
    await app.audit.log("get_product_list", cache_params, "success", elapsed)

    return result


@mcp.tool(
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def get_product_info(
    product_id: int = 0,
    offer_id: str = "",
    sku: int = 0,
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Получить подробную информацию о товаре на Ozon.

    Укажите хотя бы один идентификатор: product_id, offer_id или sku.
    Возвращает: название, описание, цены, остатки, категорию, рейтинг.

    Args:
        product_id: ID товара на Ozon (число)
        offer_id: Артикул продавца (строка)
        sku: SKU товара (число)
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    params = GetProductInfoParams(
        product_id=product_id, offer_id=offer_id, sku=sku,
    )

    if not any([params.product_id, params.offer_id, params.sku]):
        return {"error": "Укажите хотя бы один: product_id, offer_id или sku"}

    await app.rate_limiter.check_global(app.settings.rate_limit_rpm)

    payload: dict[str, Any] = {}
    if params.product_id:
        payload["product_id"] = params.product_id
    if params.offer_id:
        payload["offer_id"] = params.offer_id
    if params.sku:
        payload["sku"] = params.sku

    # Кэш по product_id
    cached = await app.cache.get("product_info", payload)
    if cached:
        await app.audit.log("get_product_info", payload, "success", 0)
        return cached

    result = await app.ozon.request("/v2/product/info", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.cache.set("product_info", payload, result, ttl=300)
    await app.audit.log("get_product_info", payload, "success", elapsed)

    return result


@mcp.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def update_prices(
    prices: list[dict[str, Any]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Обновить цены товаров на Ozon.

    ВНИМАНИЕ: Деструктивная операция — изменяет реальные цены в магазине!
    Каждый элемент должен содержать product_id и price.

    Args:
        prices: Список обновлений. Каждый элемент:
            - product_id (int): ID товара
            - price (str): Новая цена (например "1999.00")
            - old_price (str, опц.): Цена до скидки (перечёркнутая)
            - min_price (str, опц.): Мин. цена для автостратегий
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    # Валидация
    params = UpdatePricesParams(prices=prices)  # type: ignore[arg-type]

    # Write rate limit (ниже глобального)
    await app.rate_limiter.check_write(app.settings.rate_limit_write_rpm)

    payload = {"prices": [p.model_dump() for p in params.prices]}
    result = await app.ozon.request("/v1/product/import/prices", payload)
    elapsed = (time.monotonic() - start) * 1000

    # Инвалидация кэша товаров и цен
    await app.cache.invalidate("products_list")
    await app.cache.invalidate("product_info")

    await app.audit.log(
        "update_prices",
        {"count": len(params.prices), "product_ids": [p.product_id for p in params.prices]},
        "success",
        elapsed,
    )

    return result


@mcp.tool(
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": True,
    }
)
async def update_stocks(
    stocks: list[dict[str, Any]],
    ctx: Context | None = None,
) -> dict[str, Any]:
    """Обновить остатки товаров на складе.

    ВНИМАНИЕ: Деструктивная операция — изменяет реальные остатки!
    Макс. 100 товаров в одном запросе. Лимит: 80 запросов/мин.

    Args:
        stocks: Список обновлений. Каждый элемент:
            - product_id (int): ID товара
            - stock (int): Количество на складе (0-999999)
            - warehouse_id (int): ID склада
    """
    assert ctx is not None
    app = get_app_context(ctx)
    start = time.monotonic()

    params = UpdateStocksParams(stocks=stocks)  # type: ignore[arg-type]

    await app.rate_limiter.check_write(app.settings.rate_limit_write_rpm)

    payload = {
        "stocks": [
            {
                "product_id": s.product_id,
                "stock": s.stock,
                "warehouse_id": s.warehouse_id,
            }
            for s in params.stocks
        ]
    }
    result = await app.ozon.request("/v2/products/stocks", payload)
    elapsed = (time.monotonic() - start) * 1000

    await app.cache.invalidate("products_list")
    await app.cache.invalidate("product_info")

    await app.audit.log(
        "update_stocks",
        {"count": len(params.stocks)},
        "success",
        elapsed,
    )

    return result
