"""
Rate limiter на Redis (Token Bucket).

Три уровня лимитов:
- Глобальный: макс. запросов к Ozon API в минуту
- Per-tool: деструктивные операции (update_prices и т.д.) — ниже лимит
- Per-session: защита от AI-агентов в retry-штормах
"""

from __future__ import annotations

import time

import redis.asyncio as aioredis
import structlog

logger = structlog.get_logger()


class RateLimitExceeded(Exception):
    """Превышен лимит запросов."""

    def __init__(self, limit: int, window: int, key: str):
        self.limit = limit
        self.window = window
        self.key = key
        super().__init__(
            f"Rate limit exceeded: {limit} requests per {window}s (key: {key})"
        )


class RateLimiter:
    """Token Bucket rate limiter на Redis."""

    PREFIX = "ratelimit"

    def __init__(self, redis_client: aioredis.Redis) -> None:
        self._redis = redis_client

    async def check(
        self,
        key: str,
        max_requests: int,
        window_seconds: int = 60,
    ) -> bool:
        """
        Проверить и зарегистрировать запрос.

        Args:
            key: Уникальный ключ (например, "global", "tool:update_prices")
            max_requests: Макс. количество запросов в окне
            window_seconds: Размер окна в секундах

        Returns:
            True если запрос разрешён

        Raises:
            RateLimitExceeded: При превышении лимита
        """
        full_key = f"{self.PREFIX}:{key}"
        now = time.time()
        window_start = now - window_seconds

        pipe = self._redis.pipeline()
        # Удаляем устаревшие записи
        pipe.zremrangebyscore(full_key, 0, window_start)
        # Считаем текущие
        pipe.zcard(full_key)
        # Добавляем новую
        pipe.zadd(full_key, {str(now): now})
        # TTL на ключ (чуть больше окна)
        pipe.expire(full_key, window_seconds + 10)

        results = await pipe.execute()
        current_count: int = results[1]

        if current_count >= max_requests:
            logger.warning(
                "rate_limit_exceeded",
                key=key,
                current=current_count,
                limit=max_requests,
            )
            raise RateLimitExceeded(max_requests, window_seconds, key)

        return True

    async def check_global(self, max_rpm: int) -> bool:
        """Проверить глобальный лимит."""
        return await self.check("global", max_rpm, 60)

    async def check_write(self, max_rpm: int) -> bool:
        """Проверить лимит для write-операций."""
        return await self.check("write", max_rpm, 60)

    async def get_remaining(self, key: str, max_requests: int) -> int:
        """Получить оставшееся количество запросов."""
        full_key = f"{self.PREFIX}:{key}"
        now = time.time()
        await self._redis.zremrangebyscore(full_key, 0, now - 60)
        current = await self._redis.zcard(full_key)
        return max(0, max_requests - int(current))
