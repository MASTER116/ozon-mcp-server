"""
Security middleware: фильтрация секретов из ответов инструментов.

Предотвращает утечку API-ключей, токенов и паролей через:
- Ответы инструментов
- Сообщения об ошибках
- Traceback
"""

from __future__ import annotations

import re
from typing import Any

import structlog

logger = structlog.get_logger()

# Паттерны для обнаружения секретов в строках
_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (re.compile(r"[a-f0-9]{32,64}", re.IGNORECASE), "***HEX_KEY***"),
    (re.compile(r"Bearer\s+[A-Za-z0-9\-._~+/]+=*", re.IGNORECASE), "Bearer ***MASKED***"),
    (re.compile(
        r"(api[_-]?key|password|secret|token|credential|auth)"
        r"\s*[:=]\s*['\"]?[^\s'\"]{8,}",
        re.IGNORECASE,
    ), "\\1=***MASKED***"),
]

# Ключи словарей, значения которых всегда маскируются
_SENSITIVE_KEYS = frozenset({
    "api_key", "apikey", "api-key",
    "password", "passwd",
    "secret", "token",
    "authorization", "auth",
    "client_secret",
    "access_token", "refresh_token",
})


def sanitize_string(value: str) -> str:
    """Маскировать потенциальные секреты в строке."""
    result = value
    for pattern, replacement in _PATTERNS:
        result = pattern.sub(replacement, result)
    return result


def sanitize_value(data: Any, _depth: int = 0) -> Any:
    """
    Рекурсивно маскировать секреты в структуре данных.

    Ограничение глубины рекурсии: 10 уровней (защита от DoS).
    """
    if _depth > 10:
        return data

    if isinstance(data, str):
        return sanitize_string(data)

    if isinstance(data, dict):
        result = {}
        for key, val in data.items():
            key_lower = str(key).lower().replace("-", "_")
            if key_lower in _SENSITIVE_KEYS:
                result[key] = "***MASKED***"
            else:
                result[key] = sanitize_value(val, _depth + 1)
        return result

    if isinstance(data, list):
        return [sanitize_value(item, _depth + 1) for item in data]

    return data


def sanitize_error(exc: Exception) -> str:
    """Маскировать секреты в сообщении об ошибке."""
    msg = str(exc)
    return sanitize_string(msg)
