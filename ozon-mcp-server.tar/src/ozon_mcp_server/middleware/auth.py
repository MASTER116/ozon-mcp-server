"""
Аутентификация MCP-клиентов.

Для stdio-транспорта аутентификация неявная (локальный процесс).
Для HTTP-транспорта: Bearer-токен в заголовке Authorization.
"""

from __future__ import annotations

import hmac

import structlog

logger = structlog.get_logger()


class AuthError(Exception):
    """Ошибка аутентификации."""


def verify_bearer_token(provided: str, expected_secret: str) -> bool:
    """
    Проверить Bearer-токен с constant-time сравнением.

    Constant-time предотвращает timing attacks.
    """
    if not expected_secret:
        # Аутентификация отключена (пустой токен в настройках)
        return True

    if not provided:
        return False

    # Убираем "Bearer " префикс
    token = provided.removeprefix("Bearer ").strip()

    return hmac.compare_digest(token.encode(), expected_secret.encode())
