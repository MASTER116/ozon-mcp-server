"""Middleware-пакет: auth, rate limiting, security."""
