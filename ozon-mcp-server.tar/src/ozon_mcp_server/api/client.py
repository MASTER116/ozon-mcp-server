"""
HTTP-клиент для Ozon Seller API.

Безопасность:
- Фиксированный base_url (защита от SSRF)
- Запрет редиректов
- SecretStr для API-ключа (не попадает в логи)
- Retry с exponential backoff для 429/5xx
- Таймауты на каждый запрос
"""

from __future__ import annotations

import ipaddress
import socket
from typing import Any

import httpx
import structlog
from pydantic import SecretStr
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

logger = structlog.get_logger()

# Приватные IP-диапазоны — запрещены для SSRF-защиты
_PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("fc00::/7"),
]


class OzonAPIError(Exception):
    """Ошибка Ozon API."""

    def __init__(self, status_code: int, message: str, trace_id: str | None = None):
        self.status_code = status_code
        self.message = message
        self.trace_id = trace_id
        super().__init__(f"Ozon API {status_code}: {message}")


class OzonRateLimitError(OzonAPIError):
    """Превышен rate limit Ozon API (429)."""


def _is_private_ip(host: str) -> bool:
    """Проверяет, является ли хост приватным IP-адресом."""
    try:
        resolved = socket.getaddrinfo(host, None)
        for _, _, _, _, sockaddr in resolved:
            ip = ipaddress.ip_address(sockaddr[0])
            if any(ip in network for network in _PRIVATE_NETWORKS):
                return True
    except (socket.gaierror, ValueError):
        return True  # При ошибке резолва — блокируем
    return False


class OzonClient:
    """Безопасный HTTP-клиент для Ozon Seller API."""

    # Фиксированный базовый URL — защита от SSRF
    BASE_URL = "https://api-seller.ozon.ru"

    def __init__(self, client_id: str, api_key: SecretStr) -> None:
        self._client_id = client_id
        self._api_key = api_key

        # Проверка SSRF при инициализации
        host = httpx.URL(self.BASE_URL).host
        if host and _is_private_ip(host):
            msg = f"SSRF blocked: {host} resolves to private IP"
            raise ValueError(msg)

        self._http = httpx.AsyncClient(
            base_url=self.BASE_URL,
            headers={
                "Client-Id": self._client_id,
                "Api-Key": self._api_key.get_secret_value(),
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(30.0, connect=10.0),
            follow_redirects=False,  # Защита от SSRF через редиректы
        )

    async def close(self) -> None:
        """Закрытие HTTP-клиента."""
        await self._http.aclose()

    @retry(
        retry=retry_if_exception_type((httpx.TimeoutException, OzonRateLimitError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        reraise=True,
    )
    async def request(self, endpoint: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        """
        Выполнить POST-запрос к Ozon Seller API.

        Args:
            endpoint: Путь API (например, /v2/product/list)
            payload: JSON-тело запроса

        Returns:
            Распарсенный JSON-ответ

        Raises:
            OzonRateLimitError: При 429
            OzonAPIError: При любой другой ошибке API
        """
        # Валидация endpoint — только относительные пути
        if endpoint.startswith(("http://", "https://")):
            msg = f"SSRF blocked: абсолютные URL запрещены ({endpoint})"
            raise ValueError(msg)
        if ".." in endpoint:
            msg = f"SSRF blocked: path traversal запрещён ({endpoint})"
            raise ValueError(msg)

        log = logger.bind(endpoint=endpoint)
        log.debug("ozon_api_request", payload_keys=list((payload or {}).keys()))

        try:
            response = await self._http.post(endpoint, json=payload or {})
        except httpx.TimeoutException:
            log.warning("ozon_api_timeout")
            raise
        except httpx.HTTPError as exc:
            log.error("ozon_api_http_error", error=str(exc))
            raise OzonAPIError(0, str(exc)) from exc

        trace_id = response.headers.get("x-o3-trace-id")

        if response.status_code == 429:
            log.warning("ozon_api_rate_limit", trace_id=trace_id)
            raise OzonRateLimitError(429, "Rate limit exceeded", trace_id)

        if response.status_code >= 400:
            body = response.text[:500]  # Обрезаем для безопасности логов
            log.error(
                "ozon_api_error",
                status=response.status_code,
                body=body,
                trace_id=trace_id,
            )
            raise OzonAPIError(response.status_code, body, trace_id)

        data: dict[str, Any] = response.json()
        log.debug("ozon_api_response", status=response.status_code, trace_id=trace_id)
        return data
