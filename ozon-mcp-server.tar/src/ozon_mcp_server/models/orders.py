"""
Модели валидации для инструментов заказов и аналитики.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator


# Допустимые статусы FBS-заказов
FBSStatus = Literal[
    "awaiting_registration",
    "acceptance_in_progress",
    "awaiting_approve",
    "awaiting_packaging",
    "awaiting_deliver",
    "arbitration",
    "client_arbitration",
    "delivering",
    "driver_pickup",
    "delivered",
    "cancelled",
    "not_accepted",
    "sent_by_seller",
]

# Допустимые метрики аналитики
AnalyticsMetric = Literal[
    "revenue",
    "ordered_units",
    "hits_view_search",
    "hits_view_pdp",
    "hits_view",
    "hits_tocart_search",
    "hits_tocart_pdp",
    "hits_tocart",
    "session_view_search",
    "session_view_pdp",
    "session_view",
    "conv_tocart_search",
    "conv_tocart_pdp",
    "conv_tocart",
    "returns",
    "cancellations",
    "delivered_units",
    "position_category",
]

AnalyticsDimension = Literal[
    "sku", "spu", "day", "week", "month", "year", "category1",
    "category2", "category3", "category4", "brand", "modelID",
]


class GetOrderListParams(BaseModel):
    """Параметры для получения списка заказов FBS."""

    status: FBSStatus = Field(
        default="awaiting_packaging",
        description="Статус заказов",
    )
    days_back: int = Field(
        default=7, ge=1, le=90,
        description="За сколько дней назад искать",
    )
    limit: int = Field(default=50, ge=1, le=1000, description="Макс. количество заказов")
    offset: int = Field(default=0, ge=0, description="Смещение для пагинации")


class GetAnalyticsParams(BaseModel):
    """Параметры для получения аналитики продаж."""

    date_from: str = Field(
        ..., description="Начало периода (YYYY-MM-DD)"
    )
    date_to: str = Field(
        ..., description="Конец периода (YYYY-MM-DD)"
    )
    metrics: list[AnalyticsMetric] = Field(
        default=["revenue", "ordered_units", "hits_view"],
        min_length=1, max_length=14,
        description="Метрики для запроса",
    )
    dimensions: list[AnalyticsDimension] = Field(
        default=["day"],
        min_length=1, max_length=3,
        description="Измерения (группировка)",
    )
    limit: int = Field(default=1000, ge=1, le=1000, description="Лимит строк")
    offset: int = Field(default=0, ge=0, description="Смещение")

    @field_validator("date_from", "date_to")
    @classmethod
    def validate_date(cls, v: str) -> str:
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", v):
            msg = f"Формат даты: YYYY-MM-DD (получено: {v!r})"
            raise ValueError(msg)
        return v


class GetFinanceParams(BaseModel):
    """Параметры для получения финансовых транзакций."""

    date_from: str = Field(..., description="Начало периода (YYYY-MM-DD)")
    date_to: str = Field(..., description="Конец периода (YYYY-MM-DD)")
    transaction_type: str = Field(
        default="all",
        description="Тип транзакции (all, orders, returns, services и т.д.)",
    )
    page: int = Field(default=1, ge=1, description="Номер страницы")
    page_size: int = Field(default=50, ge=1, le=1000, description="Размер страницы")

    @field_validator("date_from", "date_to")
    @classmethod
    def validate_date(cls, v: str) -> str:
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", v):
            msg = f"Формат даты: YYYY-MM-DD (получено: {v!r})"
            raise ValueError(msg)
        return v
