"""
Модели валидации для инструментов товаров.

Строгая типизация, allowlist для перечислений, ограничения длины и диапазонов.
Каждый параметр — потенциальная точка входа для атаки, поэтому валидация обязательна.
"""

from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, Field, field_validator


# Допустимые значения видимости товаров (allowlist)
ProductVisibility = Literal[
    "ALL",
    "VISIBLE",
    "INVISIBLE",
    "EMPTY_STOCK",
    "NOT_MODERATED",
    "MODERATED",
    "DISABLED",
    "STATE_FAILED",
    "READY_TO_SUPPLY",
    "VALIDATION_STATE_PENDING",
    "VALIDATION_STATE_FAIL",
    "VALIDATION_STATE_SUCCESS",
    "TO_SUPPLY",
    "IN_SALE",
    "REMOVED_FROM_SALE",
    "BAN_NOT_CONFIRMED",
    "OVERPRICED",
    "CRITICALLY_OVERPRICED",
    "EMPTY_BARCODE",
    "BARCODE_EXISTS",
    "QUARANTINE",
    "ARCHIVED",
    "OVERPRICED_WITH_STOCK",
    "PARTIAL_APPROVED",
    "IMAGE_ABSENT",
    "MODERATION_BLOCK",
]


class GetProductListParams(BaseModel):
    """Параметры для получения списка товаров."""

    limit: int = Field(default=100, ge=1, le=1000, description="Количество товаров")
    last_id: str = Field(
        default="", max_length=64, description="ID для пагинации (из предыдущего ответа)"
    )
    visibility: ProductVisibility = Field(
        default="ALL", description="Фильтр видимости"
    )
    offer_ids: list[str] = Field(
        default_factory=list, max_length=1000,
        description="Фильтр по артикулам продавца",
    )
    product_ids: list[int] = Field(
        default_factory=list, max_length=1000,
        description="Фильтр по ID товаров Ozon",
    )

    @field_validator("offer_ids", mode="before")
    @classmethod
    def validate_offer_ids(cls, v: list[str]) -> list[str]:
        for oid in v:
            if not re.match(r"^[a-zA-Z0-9_\-\.]{1,64}$", str(oid)):
                msg = f"Недопустимый offer_id: {oid!r}"
                raise ValueError(msg)
        return v

    @field_validator("last_id")
    @classmethod
    def validate_last_id(cls, v: str) -> str:
        if v and not re.match(r"^[a-zA-Z0-9_\-]{0,64}$", v):
            msg = f"Недопустимый last_id: {v!r}"
            raise ValueError(msg)
        return v


class GetProductInfoParams(BaseModel):
    """Параметры для получения информации о товаре."""

    product_id: int = Field(default=0, ge=0, description="ID товара на Ozon")
    offer_id: str = Field(default="", max_length=64, description="Артикул продавца")
    sku: int = Field(default=0, ge=0, description="SKU товара")

    @field_validator("offer_id")
    @classmethod
    def validate_offer_id(cls, v: str) -> str:
        if v and not re.match(r"^[a-zA-Z0-9_\-\.]{1,64}$", v):
            msg = f"Недопустимый offer_id: {v!r}"
            raise ValueError(msg)
        return v


class PriceUpdate(BaseModel):
    """Обновление цены одного товара."""

    product_id: int = Field(..., gt=0, description="ID товара")
    price: str = Field(..., pattern=r"^\d+(\.\d{1,2})?$", description="Новая цена")
    old_price: str = Field(
        default="0",
        pattern=r"^\d+(\.\d{1,2})?$",
        description="Старая цена (перечёркнутая)",
    )
    min_price: str = Field(
        default="0",
        pattern=r"^\d+(\.\d{1,2})?$",
        description="Минимальная цена для автостратегий",
    )


class UpdatePricesParams(BaseModel):
    """Параметры для массового обновления цен."""

    prices: list[PriceUpdate] = Field(
        ..., min_length=1, max_length=1000,
        description="Список обновлений цен (макс. 1000)",
    )


class StockUpdate(BaseModel):
    """Обновление остатка одного товара на складе."""

    product_id: int = Field(..., gt=0, description="ID товара")
    stock: int = Field(..., ge=0, le=999999, description="Количество на складе")
    warehouse_id: int = Field(..., gt=0, description="ID склада")


class UpdateStocksParams(BaseModel):
    """Параметры для массового обновления остатков."""

    stocks: list[StockUpdate] = Field(
        ..., min_length=1, max_length=100,
        description="Список обновлений остатков (макс. 100 в запросе)",
    )
