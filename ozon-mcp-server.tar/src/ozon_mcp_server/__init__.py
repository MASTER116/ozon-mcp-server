"""Ozon Seller MCP Server — первый MCP-сервер для Ozon Seller API."""

__version__ = "0.1.0"
