"""
Ozon Seller MCP Server — главный модуль.

Инициализация FastMCP-сервера с:
- Lifespan (подключения к Redis, PostgreSQL, Ozon API)
- Middleware (аудит, rate limiting, credential filtering)
- Регистрация всех инструментов через импорт модулей
"""

from __future__ import annotations

import re
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any

import asyncpg
import redis.asyncio as aioredis
import structlog

from mcp.server.fastmcp import FastMCP

from ozon_mcp_server.api.client import OzonClient
from ozon_mcp_server.cache.redis_cache import RedisCache
from ozon_mcp_server.config import Settings, get_settings
from ozon_mcp_server.db.audit_repo import AuditLogger
from ozon_mcp_server.middleware.rate_limit import RateLimiter

logger = structlog.get_logger()

# Паттерн для маскировки секретов в ответах
_SECRET_RE = re.compile(r"[a-f0-9]{32,}", re.IGNORECASE)


@dataclass
class AppContext:
    """Контекст приложения — доступен через ctx.request_context.lifespan_context."""

    settings: Settings
    ozon: OzonClient
    cache: RedisCache
    rate_limiter: RateLimiter
    audit: AuditLogger
    db: asyncpg.Pool


@asynccontextmanager
async def app_lifespan(server: FastMCP) -> AsyncIterator[AppContext]:
    """Управление жизненным циклом: подключения к БД, кэш, HTTP-клиент."""
    settings = get_settings()

    # PostgreSQL
    db_pool = await asyncpg.create_pool(
        settings.postgres_dsn.get_secret_value(),
        min_size=2,
        max_size=10,
    )
    audit = AuditLogger(db_pool)
    await audit.init_schema()

    # Redis
    redis_client = aioredis.from_url(
        settings.redis_url,
        decode_responses=True,
    )
    cache = RedisCache(redis_client, default_ttl=settings.cache_ttl_seconds)
    rate_limiter = RateLimiter(redis_client)

    # Ozon HTTP-клиент
    ozon = OzonClient(
        client_id=settings.ozon_client_id,
        api_key=settings.ozon_api_key,
    )

    logger.info(
        "server_started",
        server_name=settings.server_name,
        transport=settings.transport,
    )

    try:
        yield AppContext(
            settings=settings,
            ozon=ozon,
            cache=cache,
            rate_limiter=rate_limiter,
            audit=audit,
            db=db_pool,
        )
    finally:
        await ozon.close()
        await redis_client.close()
        await db_pool.close()
        logger.info("server_stopped")


# --- Инициализация MCP-сервера ---
mcp = FastMCP(
    "Ozon Seller MCP Server",
    lifespan=app_lifespan,
)


def get_app_context(ctx: Any) -> AppContext:
    """Извлечь AppContext из MCP Context (хелпер для инструментов)."""
    return ctx.request_context.lifespan_context  # type: ignore[no-any-return]
