"""
Фикстуры для тестов.

- Мок Ozon API через pytest-httpx
- Тестовые настройки (без реальных ключей)
- Фикстуры для Redis и PostgreSQL (если доступны)
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from pydantic import SecretStr

from ozon_mcp_server.api.client import OzonClient
from ozon_mcp_server.cache.redis_cache import RedisCache
from ozon_mcp_server.config import Settings
from ozon_mcp_server.db.audit_repo import AuditLogger
from ozon_mcp_server.middleware.rate_limit import RateLimiter


@pytest.fixture()
def test_settings() -> Settings:
    """Тестовые настройки — никаких реальных ключей."""
    return Settings(
        ozon_client_id="test_client_123",
        ozon_api_key=SecretStr("test_api_key_00000000000000000000"),
        redis_url="redis://localhost:6379/15",  # отдельная БД для тестов
        postgres_dsn=SecretStr("postgresql://test:test@localhost:5432/test_ozon_mcp"),
        rate_limit_rpm=1000,
        rate_limit_write_rpm=100,
        log_level="DEBUG",
    )


@pytest.fixture()
def mock_ozon_client() -> AsyncMock:
    """Мок OzonClient — не делает реальных HTTP-запросов."""
    client = AsyncMock(spec=OzonClient)
    client.request = AsyncMock(return_value={"result": []})
    client.close = AsyncMock()
    return client


@pytest.fixture()
def mock_redis() -> MagicMock:
    """Мок Redis-клиента."""
    redis = MagicMock()
    redis.get = AsyncMock(return_value=None)
    redis.setex = AsyncMock()
    redis.delete = AsyncMock(return_value=0)
    redis.scan_iter = MagicMock(return_value=iter([]))
    redis.pipeline = MagicMock()

    # Pipeline mock
    pipe = MagicMock()
    pipe.zremrangebyscore = MagicMock()
    pipe.zcard = MagicMock()
    pipe.zadd = MagicMock()
    pipe.expire = MagicMock()
    pipe.execute = AsyncMock(return_value=[None, 0, True, True])
    redis.pipeline.return_value = pipe

    return redis


@pytest.fixture()
def mock_cache(mock_redis: MagicMock) -> RedisCache:
    """Кэш с мок-Redis."""
    return RedisCache(mock_redis, default_ttl=300)


@pytest.fixture()
def mock_rate_limiter(mock_redis: MagicMock) -> RateLimiter:
    """Rate limiter с мок-Redis."""
    return RateLimiter(mock_redis)


@pytest.fixture()
def mock_audit() -> AsyncMock:
    """Мок аудит-логгера."""
    audit = AsyncMock(spec=AuditLogger)
    audit.log = AsyncMock()
    audit.init_schema = AsyncMock()
    return audit


# --- Моки ответов Ozon API ---

PRODUCT_LIST_RESPONSE = {
    "result": {
        "items": [
            {"product_id": 123456, "offer_id": "SKU-001"},
            {"product_id": 123457, "offer_id": "SKU-002"},
        ],
        "total": 2,
        "last_id": "123457",
    }
}

PRODUCT_INFO_RESPONSE = {
    "result": {
        "id": 123456,
        "name": "Test Product",
        "offer_id": "SKU-001",
        "barcode": "4600000000001",
        "price": "1999.00",
        "old_price": "2499.00",
        "stocks": {"present": 50, "reserved": 5},
        "visibility_details": {"has_price": True, "has_stock": True},
        "status": {"state": "processed", "is_created": True},
    }
}

FBS_ORDERS_RESPONSE = {
    "result": {
        "postings": [
            {
                "posting_number": "12345678-0001-1",
                "status": "awaiting_packaging",
                "products": [
                    {"name": "Test Product", "offer_id": "SKU-001", "quantity": 1, "price": "1999.00"}
                ],
                "analytics_data": {"region": "Moscow"},
            }
        ],
        "has_next": False,
    }
}

WAREHOUSE_LIST_RESPONSE = {
    "result": [
        {"warehouse_id": 100, "name": "Main FBS Warehouse", "status": "new"},
    ]
}

UPDATE_PRICES_RESPONSE = {
    "result": [
        {"product_id": 123456, "updated": True, "errors": []},
    ]
}

ANALYTICS_RESPONSE = {
    "result": {
        "data": [
            {"dimensions": [{"id": "2026-04-01"}], "metrics": [50000.0, 25, 1200]},
            {"dimensions": [{"id": "2026-04-02"}], "metrics": [62000.0, 31, 1450]},
        ],
        "totals": [112000.0, 56, 2650],
    },
    "timestamp": "2026-04-04T10:00:00Z",
}
